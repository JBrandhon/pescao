
 <?php $temp = 0 ?>
<?php if (sizeof($records) > 0 ) : ?>
	<?php foreach($records as $record) : ?>
		<?php if ( $record['status'] == 'Paid' ) : ?>
			<?php  
				$temp += $record['payable'];
			?>
		<?php endif; ?>
	<?php endforeach; ?>
<?php endif; ?>
<!--================Category Product Area =================-->
<section class="cat_product_area section-top border_top">
   <div class="container">
      <div class="row">
         <div class="col-lg-12">
            <div class="row">
               <div class="col-lg-12">
                  <div class="product_top_bar d-flex justify-content-between align-items-center">
                     <div class="single_product_menu product_bar_item">
                        <h2>Report</h2>
                     </div>
                     <div class="product_top_bar_iner product_bar_item d-flex">
                        <div class="product_bar_single">
							<div id="reportrange" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc; width: 100%">
								<i class="fa fa-calendar"></i>&nbsp;
								<span></span> <i class="fa fa-caret-down"></i>
							</div>
                     </div>
                  </div>
               </div>
			   <div class="col-lg-12" >
				   <table id="dtBasicExample" class="table table-bordered">
					   <thead>
						  <tr>
							<th class="th-sm" scope="col">Full Name</th>
							<th class="th-sm" scope="col">Phone Number</th>
							<th class="th-sm" scope="col">Address</th>
							<th class="th-sm" scope="col">Item Name</th>
							<th class="th-sm" scope="col">Rented Quantity</th>
							<th class="th-sm" scope="col">Rented Date</th>
							<th class="th-sm" scope="col">Payable</th>
							<th class="th-sm" scope="col">Status</th>
						  </tr>
					   </thead>
				   <tbody>
					 
							 <?php if (sizeof($records) > 0 ) : ?>
							 <?php foreach($records as $record) : ?>
								  <tr  name="pname">
									 <td class='fname'><?php echo ucwords($record['first_name']).' '.ucwords($record['last_name']) ?></td>
									 <td class='phone'><?php echo $record['phone'] ?></td>
									 <td class='phone'><?php echo $record['address'] ?></td>
									 <td class='phone'><?php echo $record['item_name'] ?></td>
									 <td class='phone'><?php echo $record['rented_qty'] ?></td>
									 <td class='phone'><?php echo $record['from'] ?></td>
									 <td class='phone'><?php echo $record['payable'] ?></td>
									 <td class='phone'><?php echo $record['status'] ?></td>
								  </tr>									
							 <?php endforeach; ?>
							 <?php endif; ?>
					  
				   </tbody>
				   </table>
				 </div>
			   
            </div>
         </div>
      </div>
   </div>
</section>

  <!--<script src=" <?php //echo base_url('assets/js/jquery-1.12.1.min.js'); ?> "></script> -->
  



<script type="text/javascript">

$(function() {

const selectElement = document.querySelector('#reportrange span');

    var start = moment().subtract(29, 'days');
    var end = moment();

    function cb(start, end) {
		console.log( start.format('YYYY-MM-D') );
		console.log( end.format('YYYY-MM-D') );
        $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
		sortReport(  start.format('YYYY-MM-D') ,  end.format('YYYY-MM-D') );
		
		
    }

    $('#reportrange').daterangepicker({
        startDate: start,
        endDate: end,
        ranges: {
		   // 'All':'',
           'Today': [moment(), moment()],
           'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
           'Last 7 Days': [moment().subtract(6, 'days'), moment()],
           'Last 30 Days': [moment().subtract(29, 'days'), moment()],
           'This Month': [moment().startOf('month'), moment().endOf('month')],
           'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        }
    }, cb);

    cb(start, end);

});

	$(document).ready(function () {
	  $('#dtBasicExample').DataTable();
	  $('.dataTables_length').addClass('bs-select ');
	});


	$(".edit").click(function() {
		$row = $(this).closest("tr");    // Find the row
		
		const ID = $(this).closest('tr').attr('id');
		const fname= $row.find(".fname").text();
		$name = fname.split(' ');

		$('.first_name').val( $name[0] ); 
		$('.last_name').val( $name[1] ); 
		$('.' + $row.find(".gender").text() ).prop('checked',true);
		$('.email').val($row.find(".email").text() ); 
		
		$('.phone').val($row.find(".phone").text() ); 
		$('.ID').val(ID); 

		$('#EditUserModal').modal('show');
	});
	
	function Delete(id){
		 var postData = {
			  'id' : id,
			};

			$.ajax({
				 type: "POST",
				 url: "http://localhost/pescao/admin/deleteUser",
				 data: {'id':id} , //assign the var here 
				 success: function(msg){
					 document.getElementById(id).style.display = "none";
				 }
			});
			
	}
	function sortReport(start , end){
		 var postData = {
			  'start' : start,
			  'end' : end,
			};
			//console.log(postData);
			$.ajax({
				 url: "http://localhost/pescao/admin/sort_report",
				 type: "POST",
				 data: postData , //assign the var here 
				 success: function (data, text) {
					//...
					 data = JSON.parse(data);
					 const result = data.map(({ FullName, phone, address, item_name, rented_qty, from, payable, status }) => [FullName, phone, address, item_name, rented_qty, from, payable, status]);
					// console.log( result );

					
					var table = $('#dtBasicExample').DataTable();
					
					var rows = table
						.clear()
						.draw();
					for(a=0;a<result.length;a++){
						var rowNode = table
							.row.add( result[a] )
							.draw()
							.node();

					}

					
				},
				error: function (request, status, error) {
					console.log(err);
				}
				   
			});
			
	}

	$('#npass, #cpass').on('keyup', function () {
		
	  if ($('#npass').val() == $('#cpass').val()) {
		  
		$('#message').html('Matching').css('color', 'green');
		 $(':input[type="submit"]').prop('disabled', false);
	  } else {
		  
		$('#message').html('Not Matching').css('color', 'red');
		$(':input[type="submit"]').prop('disabled', true);
	  
	  }
	});

</script>


<section class="cat_product_area section-top border_top">
   <div class="container">
      <div class="row">
         <div class="col-lg-12">
            <div class="row">
               <div class="col-lg-12">
                  <div class="product_top_bar d-flex justify-content-between align-items-center">
                     <div class="single_product_menu product_bar_item">
                        <h2>Report</h2>
                     </div>
               </div>
			   <div class="col-lg-12" >
				   <table id="dtBasicExample" class="table table-bordered">
					   <thead>
						  <tr>
							<th class="th-sm" scope="col">Item Name</th>
							<th class="th-sm" scope="col">Remaining Quantity</th>
							<th class="th-sm" scope="col">Total Item Quantity</th>
							<th class="th-sm" scope="col">Total Item Lost</th>
							<th class="th-sm" scope="col">Rental Prize</th>
							<th class="th-sm" scope="col">Revenue</th>
						  </tr>
					   </thead>
				   <tbody>
					  
				   </tbody>
				   </table>
				 </div>
			   
            </div>
         </div>
      </div>
   </div>
</section>


<script type="text/javascript">

$(function() {

	$(document).ready(function () {
	  $('#dtBasicExample').DataTable();
	  $('.dataTables_length').addClass('bs-select ');
	});


	
		 var postData = {
			  'start' : 'test',
			  'end' : 'test',
			};
			//console.log(postData);
			$.ajax({
				 url: "http://localhost/pescao/admin/item_lost_report",
				 type: "POST",
				 data: postData , //assign the var here 
				 success: function (data, text) {
					//...
					console.log('data');
					console.log(data);
					
					 data = JSON.parse(data);
					 const result = data.map(({ item_name, remaining_quantity, total_item_qty, total_item_lost, rental_prize, revenue }) => [item_name, remaining_quantity, total_item_qty, total_item_lost, rental_prize, revenue]);
					// console.log( result );

					
					var table = $('#dtBasicExample').DataTable();
					
					var rows = table
						.clear()
						.draw();
					for(a=0;a<result.length;a++){
						var rowNode = table
							.row.add( result[a] )
							.draw()
							.node();

					}

					
				},
				error: function (request, status, error) {
					console.log(err);
				}
				   
			});
			
	
});

</script>

<!--================Checkout Area =================-->
  <section class="product_image_area section-top section_padding">
    <div class="container">
      <div class="billing_details">
        <div class="row">
          <div class="col-lg-8">
            <h3>Billing Details</h3>
            <form class="row contact_form" action="#" method="post" novalidate="novalidate">
			  <input type="text" class="form-control" id="id" name="ID" value="<?php echo ( sizeof($rentee) > 0  ? $rentee[0]['id'] : '' ) ?>" hidden/>
			  <input type="text" class="form-control" id="reciept_number" name="reciept_number" value="<?php echo ( sizeof($rentee) > 0  ? $rentee[0]['reciept_number'] : '' ) ?>" hidden/>
              <div class="col-md-6 form-group p_star">
                <span id="label_f"> First name </span>
				<input type="text" class="form-control" id="first" name="name" value="<?php echo ( sizeof($rentee) > 0  ? $rentee[0]['first_name'] : '' ) ?>" />
				<div id="danger_f" class="alert alert-danger" role="alert" style="display: none;">
				  This is field is required.
				</div>
              </div>
              <div class="col-md-6 fo	rm-group p_star">
                <span id="label_l">Last name</span>
				<input type="text" class="form-control" id="last" name="name"  value="<?php echo ( sizeof($rentee) > 0  ? $rentee[0]['last_name'] : '' ) ?>"/>
                <div id="danger_l" class="alert alert-danger" role="alert" style="display: none;">
				  This is field is required.
				</div>
              </div>
              <div class="col-md-6 form-group p_star">
				<span id="label_p">Phone number</span>
                <input  class="form-control" id="number" name="number"  
				oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);"
					type = "number"
					maxlength = "11"
				value="<?php echo ( sizeof($rentee) > 0  ? $rentee[0]['phone'] : '' ) ?>" />
                <div id="danger_p" class="alert alert-danger" role="alert" style="display: none;">
				  Please provide a valid phone number.
				</div>
              </div>
              <div class="col-md-6 form-group p_star">
				<span id="label_e">Email Address</span>
                <input type="email" class="form-control" id="email" name="compemailany"  value="<?php echo ( sizeof($rentee) > 0  ? $rentee[0]['email'] : '' ) ?>"/>
                <div id="danger_e" class="alert alert-danger" role="alert" style="display: none;">
				  Please provide a valid email address.
				</div>
              </div>
              <div class="col-md-12 form-group p_star">
				<span id="label_a">Address</span>
                <input type="text" class="form-control" id="city" name="city"  value="<?php echo ( sizeof($rentee) > 0  ? $rentee[0]['address'] : '' ) ?>"/>
                <div id="danger_a" class="alert alert-danger" role="alert" style="display: none;">
				  This is field is required.
				</div>
              </div>
            </form>
          </div>
          <div class="col-lg-4">
            <div class="order_box">
				<div class="col-lg-12"  style="display:flex">
					<h2 class="col" >Your Item</h2>
					<h2 class="col" ><i><?php echo ( sizeof($rentee) > 0  ? $rentee[0]['reciept_number'] : '' ) ?></i></h2>
				</div>
              <ul class="list">
                <li>
                  <a href="#">Item
                    <span>Total</span>
                  </a>
                </li>
					<?php if (sizeof($cart) > 0) : ?>
						<?php foreach($cart as $item) : ?>
							<li>
							  <a href="<?php echo base_url('single_costume/view/').$item['item_id'] ?>"><?php echo $item['name']
							  ?> 
								<span style = "width: unset;" class="middle" ><?php echo '₱'.$item['rental_prize'].' x '. $item['qty'] ?></span>
								<input class="payable" value = <?php  echo $item['payable'] ?> hidden />
								<span id="payable" class="last"> </span>
							  </a>
							</li>
						<?php endforeach; ?>
					 <?php endif; ?>
              </ul>
              <ul class="list list_2">
                <li>
                  <a href="#">Total
                    <span></span>
                  </a>
                </li>
              </ul>
				<?php if ( sizeof($cart) == 0) : ?>
					<div style="padding:0" class="alert alert-check" role="alert">
						<a class="btn_3 add-to-cart" id="return" style=" font-size: 12px;" href="/pescao/admin/dashboard"> Add something into your cart. </a> 
					</div>
				<?php endif; ?>
			  <?php
			  
				if( $return != 0 ){
					echo '<div> <a class="btn_3 btn-returnItem" id="return" href="#" style=" font-size: 12px;">Return Items</a> </div> ';
					echo '<div class="button-group-area mt-1"><a style=" line-height: 38px; padding: 9px 42px;" href="/pescao/rentor/item_lost/'.$rentee[0]["reciept_number"].'" class="btn_3 genric-btn danger-border">Report Item Lost</a></div>';
				}else{
					echo ( sizeof($cart) > 0 ? '<a target="_blank" class="btn_3 btn-proceedcheckout" id="checkout"  href="/pescao/rentor/reciept/'.$recieptId.'">Proceed to Checkout</a>' : '' ) ;
					echo( $recieptId == '' ? '  <a class="btn_3 btn-registercheckout" id="register" href="/pescao/admin/dashboard" style=" font-size: 12px;">Register to Checkout Items</a>' : '');
				}
			  ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
	
	<style>
		.btn-registercheckout{
			background-color: #fff;
			border: 1px solid #f57224;
			color: #f57224;
		}
		.btn-registercheckout:hover{
			background-color: #f57224;
			border: 1px solid #f57224;
		}
		.add-to-cart:hover,
		.btn-returnItem:hover{
			background-color: #fff;
			color: #2f7dfc!important;
		}
		
		
	</style>

  <!--<script src=" <?php //echo base_url('assets/js/jquery-1.12.1.min.js'); ?> "></script> -->
  <script>
	$(document).ready(function(){
		
		var elementExists = document.getElementById("payable");
		if( elementExists ){
			var number = parseInt( $( 	".payable" ).val() );
			document.getElementById("payable").innerHTML = '₱'+number.toLocaleString()+'.00';	
			
		}

		function validateEmail(email) {
		  const re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		  return re.test(email);
		}
		
		$("#register").click(function(){     
				$f_name = $( "#first" ).val();
				$l_name = $( "#last" ).val();
				$phone = $( "#number" ).val();
				$email = $( "#email" ).val() ;
				$address = $( "#city" ).val();
				$itemId = $( "#itemId" ).val();
				$qty = $( "#qty" ).val();
				$rental_prize = $( "#rental_prize" ).val();
				if( $f_name == "" ){
					//$("#label_f").hide();
					$("#danger_f").show();
					return false;
				}
				if( $l_name == "" ){
					//$("#label_l").hide();
					$("#danger_l").show();
					return false;
				}
				let re = new RegExp(/^(09|\+639)\d{9}$/g);
				if( $phone  == "" ||  !$phone.match(re) ){
					//$("#label_p").hide();
					$("#danger_p").show();
					return false;
				}else{
					
				}
				if( !validateEmail( $( "#email" ).val() ) ){
					//alert('Invalid Email');
					//$("#label_e").hide();
					$("#danger_e").show();
					return false;
				}
				if( $address  == "" ){
					//$("#label_a").hide();
					$("#danger_a").show();
					return false;
				}
				
				

		 var postData = {
			  'first_name' : $f_name,
			  'last_name'  : $l_name,
			  'address'    : $address,
			  'phone'      : $phone,
			  'email'      : $email,
			  'city'       : $address,
			  'itemId'     : $itemId,
			  'qty'        : $qty,
			 'rental_prize': $rental_prize,
			};
			console.log( postData );
			$.ajax({
				 type: "POST",
				 url: "/pescao/checkout/rentee",
				 data: postData , //assign the var here 
				 success: function(test){
					  window.location.replace("/pescao/admin/dashboard");
					  console.log(test);
				 }
			});
			
		});
		
		$("#checkout").click(function(){ 
			$id = $( "#id" ).val();
			var postData = {
			  'id' : $id
			};
			
			$.ajax({
				 type: "POST",
				 url: "/pescao/checkout/saveCheckout",
				 data: postData , //assign the var here 
				 success: function(test){
					  window.location.replace("/pescao/admin/dashboard");
					  console.log(test);
				 }
			});
		});
		
 		$("#return").click(function(){ 
			$id = $( "#id" ).val();
			$reciept_number = $( "#reciept_number" ).val();
			var postData = {
			  'id' : $id,
			  'reciept_number' : $reciept_number,
			};
			
			$.ajax({
				 type: "POST",
				 url: "/pescao/inventory/returnItem",
				 data: postData , //assign the var here 
				 success: function(test){
					  window.location.replace("/pescao/admin/dashboard");
					  console.log(test);
				 }
			});
		});  
		
	});
</script>
